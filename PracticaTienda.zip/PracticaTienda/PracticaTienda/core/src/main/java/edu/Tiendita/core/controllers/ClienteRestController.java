package edu.Tiendita.core.controllers;

import org.apache.coyote.BadRequestException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.net.URI;
import java.util.*;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import edu.Tiendita.core.domain.Cliente;
import edu.Tiendita.core.exceptions.ResourceNotFoundException;

@RestController
@RequestMapping("/clientes")
public class ClienteRestController {
    private List<Cliente> clientes =new ArrayList<>(Arrays.asList(
        new Cliente("Chuy", "1111", "Jose"),
        new Cliente("Lucho", "1111", "Luis"),
        new Cliente("Many", "1111", "Manuel")

    )
    );

    @GetMapping
    public ResponseEntity<List<?>> getClientes(){
        return ResponseEntity.ok(clientes);
    }

    @GetMapping("/{userName}")
    public ResponseEntity<?> getCliente(@PathVariable String userName) throws BadRequestException{
        if(userName.length()!=5){
            throw new BadRequestException("El nombre de usuaro debe contener 5 caracteres.");
        }
        return clientes.stream().
        filter(cliente->cliente.getUsername().
        equalsIgnoreCase(userName)).
        findFirst().map(ResponseEntity::ok).
        orElseThrow(()->new ResourceNotFoundException("Cliente " + userName + " no encontrado"));
    }

    @PostMapping
    public ResponseEntity<?> altacliente(@RequestBody Cliente cliente){
        clientes.add(cliente);

        URI location = ServletUriComponentsBuilder.
        fromCurrentRequest().
        path("/{userName}").
        buildAndExpand(cliente.getUsername()).
        toUri();
        return ResponseEntity.created(location).body(cliente);
    }

    @PutMapping
    public ResponseEntity<?> modificacionCliente(@RequestBody Cliente cliente){

        Cliente clienteEncontrado = clientes.stream().
        filter(cli->cli.getUsername().equalsIgnoreCase(cliente.getUsername())).
        findFirst().orElseThrow();
        clienteEncontrado.setPassword(cliente.getPassword());
        clienteEncontrado.setNombre(cliente.getNombre());
        return ResponseEntity.ok(clienteEncontrado);
    }

    @DeleteMapping("/{userName}")
    public ResponseEntity<?> deleteCliente(@PathVariable String userName){
        Cliente clienteEncontrado =clientes.stream().
        filter(cli->cli.getUsername().equalsIgnoreCase(userName)).
        findFirst().orElseThrow();
        clientes.remove(clienteEncontrado);
        return ResponseEntity.noContent().build();
    }
}