package edu.Tiendita.core.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseBody
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class BadRequestExeption extends RuntimeException{
    public BadRequestExeption(String message){
        super(message);
    }
    @Override
    public String getMessage(){
        return super.getMessage();
    }
}
